Enchantment Outlines — Eaglercraft 26.2 U2 asset conversion

Target: Eaglercraft 26.2 U2 (the user's native 26.x item-definition runtime).

Included:
- Base textures and model assets.
- Cumulative resource/model/item-definition updates through the 26.1 overlay, which is the matching overlay range for 26.2.
- 26.2-compatible pack metadata.
- Non-Minecraft namespaces included by the original pack (Enderscape and Farmer's Delight).

Removed:
- 26.3-only overlay.
- Java Edition GLSL shader overrides. These are not WebGL2/Eagler pipeline shaders and replacing the runtime shaders with them can break rendering.
- RespackOpts config and .rpo sidecars. The Eagler runtime does not include RespackOpts.

Important runtime note:
This ZIP is the Eagler-compatible asset/model conversion. The original enchantment-outline shader behavior (including the special alpha-marker handling and custom glint composition) is not reproduced by a resource-pack ZIP alone. That effect requires a matching native Eagler WebGL2 item-pipeline/runtime patch. The ZIP deliberately does not overwrite the client's native shaders.
